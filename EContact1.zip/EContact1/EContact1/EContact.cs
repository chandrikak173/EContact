﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using EContact1.econtactClasses;

namespace EContact1
{
    public partial class EContact : Form
    {
        public EContact()
        {
            InitializeComponent();
        }
        contactClass c = new contactClass();

        private void lblContactID_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void EContact_Load(object sender, EventArgs e)
        {
            //Once Data is inserted, the data has to be loaded on the datagrid
            DataTable dt = c.Select();
            dgvContactList.DataSource = dt;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {              

                //Get the values from the input field
                c.FirstName = txtboxFirstName.Text;
                c.LastName = txtboxLastName.Text;
                c.ContactNumber = txtboxContactNumber.Text;
                c.Email = txtboxEmail.Text;
                c.Address = txtboxAddress.Text;
                c.Gender = cmbGender.Text;

                // Inserting the values read to DB using the methods created in contactClass.cs
                bool success=c.Insert(c);
                if(success == true)
                {
                    MessageBox.Show("Contact inserted successfully");
                    //clears the fiels once the data inserted successfully
                    ClearBox();

                }
                else
                {
                    MessageBox.Show("Failed to add new contact.");
                }

                //Once Data is inserted, the data has to be loaded on the datagrid
                DataTable dt = c.Select();
                dgvContactList.DataSource = dt;
             }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

           
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //Method to clear the input fields once data is inserted
        public void ClearBox()
        {
            txtboxFirstName.Text = "";
            txtboxLastName.Text = "";
            txtboxContactNumber.Text = "";
            txtboxEmail.Text = "";
            txtboxAddress.Text = "";
            cmbGender.Text = "";
            txtboxContactID.Text = "";

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //To update the data, the data must be loaded in to the input fields to edit
            c.ContactID = int.Parse(txtboxContactID.Text);   //coverting txt to int
            c.FirstName = txtboxFirstName.Text;
            c.LastName = txtboxLastName.Text;
            c.ContactNumber = txtboxContactNumber.Text;
            c.Email = txtboxEmail.Text;
            c.Address = txtboxAddress.Text;
            c.Gender = cmbGender.Text;

            //Update data in DB
            bool success = c.Update(c);
            if(success == true)
            {
                MessageBox.Show("The contact has been updated successfully");

                //Once Data is updated, the data has to be loaded on the datagrid
                DataTable dt = c.Select();
                dgvContactList.DataSource = dt;
                ClearBox();

            }
            else
            {
                MessageBox.Show("Failed to update the contact");
            }
        }

        // Function to fill in the data from the selected row into the text fields
        private void dgvContactList_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //To get the data from the selected row from the datagrid and load to text boxes
            //Identify the row on which the mouse is clicked
            int rowIndex = e.RowIndex;
            txtboxContactID.Text = dgvContactList.Rows[rowIndex].Cells[0].Value.ToString();
            txtboxFirstName.Text = dgvContactList.Rows[rowIndex].Cells[1].Value.ToString();
            txtboxLastName.Text = dgvContactList.Rows[rowIndex].Cells[2].Value.ToString();
            txtboxContactNumber.Text = dgvContactList.Rows[rowIndex].Cells[3].Value.ToString();
            txtboxEmail.Text = dgvContactList.Rows[rowIndex].Cells[4].Value.ToString();
            txtboxAddress.Text = dgvContactList.Rows[rowIndex].Cells[5].Value.ToString();
            cmbGender.Text = dgvContactList.Rows[rowIndex].Cells[6].Value.ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearBox();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // the contactID has to be fetched from the data grid to delete the particular row
            c.ContactID = int.Parse(txtboxContactID.Text); //can also be converted using: c.ContactID = Convert.ToInt32(txtboxContactID.Text);
            bool success = c.Delete(c);
            if (success == true)
            {
                MessageBox.Show("The selected contact has been deleted successfully");
                //Once Data is updated, the data has to be loaded on the datagrid
                DataTable dt = c.Select();
                dgvContactList.DataSource = dt;
                ClearBox();
            }
            else
            {
                MessageBox.Show("Failed to delete the selected contact");
            }
        }

        private void txtboxSearch_TextChanged(object sender, EventArgs e)
        {
            string keyword = txtboxSearch.Text;
            DataTable dt= c.Search(keyword);
            //Once Data is updated, the data has to be loaded on the datagrid            
            dgvContactList.DataSource = dt;
            ClearBox();
        }
    }

}